﻿using Guna.UI2.WinForms;
using SMS_CSC235.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using SMS_CSC235.Models;
using Newtonsoft.Json;

namespace SMS_CSC235
{

    public partial class Dashboard : Form
    {
        private string filePath = "students.json";
        public SortableBindingList<cStudent> StudentData { get; set; }
        public SortableBindingList<cStudent> OriginalStudentList { get; private set; }
        public string LoggedInRole { get; set; } = "Admin";

        public Dashboard()
        {
            InitializeComponent();

            btnViewStudent.Click += btnViewStudent_Click;
            btnSearchStudent.Click += btnSearchStudent_Click;
            btnEditStudent.Click += btnEditStudent_Click;
            btnAddStudent.Click += btnAddStudent_Click;
            btnDeleteStudent.Click += btnDeleteStudent_Click;

            LoadStudentsFromFile();
            LoadUserControl(new UC_Homepage());
        }

        public void SaveStudentsToFile()
        {
            string json = JsonConvert.SerializeObject(StudentData, Formatting.Indented);
            File.WriteAllText(filePath, json);
        }

        private void LoadStudentsFromFile()
        {
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                StudentData = JsonConvert.DeserializeObject<SortableBindingList<cStudent>>(json) ?? new SortableBindingList<cStudent>();
            }
            else
            {
                StudentData = new SortableBindingList<cStudent>();
            }

            OriginalStudentList = new SortableBindingList<cStudent>(StudentData);
        }

        public SortableBindingList<cStudent> SearchStudents(string criteria)
        {
            criteria = criteria.Trim().ToLower();

            if (string.IsNullOrEmpty(criteria))
            {
                StudentData = new SortableBindingList<cStudent>(OriginalStudentList);
            }
            else
            {
                var filteredList = OriginalStudentList
                    .Where(s => s.Name.ToLower().Contains(criteria) ||
                                s.Major.ToLower().Contains(criteria) ||
                                s.Phone.Contains(criteria) ||
                                s.Birthday.ToString("yyyy/MM/dd").Contains(criteria) ||
                                s.ID.ToString() == criteria)
                    .ToList();

                StudentData = new SortableBindingList<cStudent>(filteredList);
            }

            return StudentData;
        }

        public void AddStudent(cStudent newStudent)
        {
             if (StudentData.Any(s => s.ID == newStudent.ID))
             {
                 MessageBox.Show("A student with this ID already exists!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                 return;
             }

             StudentData.Add(newStudent);
             OriginalStudentList.Add(newStudent);
            SaveStudentsToFile(); 

            MessageBox.Show($"Student {newStudent.Name} has been added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void DeleteStudent(int studentID)
        {
            var studentToRemove = StudentData.FirstOrDefault(s => s.ID == studentID);

            if (studentToRemove != null)
            {
                StudentData.Remove(studentToRemove);
                OriginalStudentList.Remove(studentToRemove);
                SaveStudentsToFile();

                MessageBox.Show($"Student with ID {studentID} has been deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Student ID not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void Dashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void LoadUserControl(UserControl uc)
        {
            panelContainer.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            panelContainer.Controls.Add(uc);
            uc.BringToFront();

            panelContainer.Controls.Clear();
            panelContainer.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
        }

        private void btnViewStudent_Click(object sender, EventArgs e)
        {
            LoadUserControl(new UC_ViewStudent(this));
        }

        private void btnSearchStudent_Click(object sender, EventArgs e)
        {
            LoadUserControl(new UC_Homepage());
        }

        private void btnEditStudent_Click(object sender, EventArgs e)
        {
            LoadUserControl(new UC_EditStudent(this));
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            LoadUserControl(new UC_AddStudent(this));
        }

        private void btnDeleteStudent_Click(object sender, EventArgs e)
        {
            LoadUserControl(new UC_DeleteStudent(this));
        }

        private void MoveSlideImageBox(object sender)
        {
            Guna2Button b = (Guna2Button)sender;
            SlidePictureBox.Location = new Point(b.Location.X + 143, b.Location.Y - 29);
            SlidePictureBox.SendToBack();
        }

        private void ViewStudentButton_CheckedChanged(object sender, EventArgs e)
        {
            MoveSlideImageBox(sender);
        }


        //-------------------------------------------------------------------------------

        private void Dashboard_Load(object sender, EventArgs e)
        {
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void ViewStudentButton_Click(object sender, EventArgs e)
        {
        }

        private void guna2PictureBox2_Click(object sender, EventArgs e)
        {
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
        }

        private void panelControlBox_Paint(object sender, PaintEventArgs e)
        {
        }

        private void btnSearchStudent_Click_1(object sender, EventArgs e)
        {
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
        }

        private void panelContainer_Paint(object sender, PaintEventArgs e)
        {
        }
    }
}
