﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_CSC235.Models
{
    public class SortableBindingList<T>:BindingList<T>
    {
 
        private bool isSorted;
        private ListSortDirection sortDirection;
        private PropertyDescriptor sortProperty;

        public SortableBindingList() : base() { }
        public SortableBindingList(IEnumerable<T> collection) : base(new List<T>(collection)) { }

        protected override bool SupportsSortingCore => true;
        protected override bool IsSortedCore => isSorted;
        protected override PropertyDescriptor SortPropertyCore => sortProperty;
        protected override ListSortDirection SortDirectionCore => sortDirection;

        protected override void ApplySortCore(PropertyDescriptor prop, ListSortDirection direction)
        {
            var items = Items as List<T>;
            if (items != null)
            {
                var propInfo = typeof(T).GetProperty(prop.Name);
                if (propInfo != null)
                {
                    items.Sort((x, y) =>
                    {
                        object valueX = propInfo.GetValue(x);
                        object valueY = propInfo.GetValue(y);
                        return direction == ListSortDirection.Ascending
                            ? Comparer<object>.Default.Compare(valueX, valueY)
                            : Comparer<object>.Default.Compare(valueY, valueX);
                    });

                    sortProperty = prop;
                    sortDirection = direction;
                    isSorted = true;

                    ResetBindings();
                }
            }
        }

        protected override void RemoveSortCore()
        {
            isSorted = false;
        }
    }
}
