﻿namespace SMS_CSC235
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2ShadowForm1 = new Guna.UI2.WinForms.Guna2ShadowForm(this.components);
            this.guna2ColorTransition1 = new Guna.UI2.WinForms.Guna2ColorTransition(this.components);
            this.PasswordTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.UsernameTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.AUIBLogoPictureBox = new Guna.UI2.WinForms.Guna2PictureBox();
            this.ShowPasswordToggleSwitch = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.ShowPasswordLabel = new System.Windows.Forms.Label();
            this.RememberMeCheckBox = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.RememberMeLabel = new System.Windows.Forms.Label();
            this.LoginButton = new Guna.UI2.WinForms.Guna2Button();
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.guna2ContextMenuStrip1 = new Guna.UI2.WinForms.Guna2ContextMenuStrip();
            this.panel1 = new System.Windows.Forms.Panel();
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox2 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.comboBoxRole = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.AUIBLogoPictureBox)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2ShadowForm1
            // 
            this.guna2ShadowForm1.TargetForm = this;
            // 
            // guna2ColorTransition1
            // 
            this.guna2ColorTransition1.ColorArray = new System.Drawing.Color[] {
        System.Drawing.Color.Red,
        System.Drawing.Color.Blue,
        System.Drawing.Color.Orange};
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PasswordTextBox.Animated = true;
            this.PasswordTextBox.AutoRoundedCorners = true;
            this.PasswordTextBox.BorderRadius = 17;
            this.PasswordTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PasswordTextBox.DefaultText = "";
            this.PasswordTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.PasswordTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.PasswordTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PasswordTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PasswordTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.PasswordTextBox.FocusedState.FillColor = System.Drawing.Color.White;
            this.PasswordTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.PasswordTextBox.ForeColor = System.Drawing.Color.DimGray;
            this.PasswordTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.PasswordTextBox.HoverState.FillColor = System.Drawing.Color.White;
            this.PasswordTextBox.IconLeft = global::SMS_CSC235.Properties.Resources.icons8_lock_50;
            this.PasswordTextBox.Location = new System.Drawing.Point(448, 204);
            this.PasswordTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.PasswordTextBox.MaxLength = 16;
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.PasswordChar = '\0';
            this.PasswordTextBox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.PasswordTextBox.PlaceholderText = "Password";
            this.PasswordTextBox.SelectedText = "";
            this.PasswordTextBox.Size = new System.Drawing.Size(245, 36);
            this.PasswordTextBox.TabIndex = 2;
            this.PasswordTextBox.TextChanged += new System.EventHandler(this.PasswordTextbox);
            // 
            // UsernameTextBox
            // 
            this.UsernameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UsernameTextBox.Animated = true;
            this.UsernameTextBox.AutoRoundedCorners = true;
            this.UsernameTextBox.BorderRadius = 17;
            this.UsernameTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.UsernameTextBox.DefaultText = "";
            this.UsernameTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.UsernameTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.UsernameTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.UsernameTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.UsernameTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.UsernameTextBox.FocusedState.FillColor = System.Drawing.Color.White;
            this.UsernameTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.UsernameTextBox.ForeColor = System.Drawing.Color.DimGray;
            this.UsernameTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.UsernameTextBox.HoverState.FillColor = System.Drawing.Color.White;
            this.UsernameTextBox.IconLeft = global::SMS_CSC235.Properties.Resources.icons8_person_64;
            this.UsernameTextBox.Location = new System.Drawing.Point(448, 158);
            this.UsernameTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.UsernameTextBox.MaxLength = 16;
            this.UsernameTextBox.Name = "UsernameTextBox";
            this.UsernameTextBox.PasswordChar = '\0';
            this.UsernameTextBox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.UsernameTextBox.PlaceholderText = "Username";
            this.UsernameTextBox.SelectedText = "";
            this.UsernameTextBox.Size = new System.Drawing.Size(245, 36);
            this.UsernameTextBox.TabIndex = 1;
            this.UsernameTextBox.TextChanged += new System.EventHandler(this.guna2TextBox1_TextChanged);
            // 
            // AUIBLogoPictureBox
            // 
            this.AUIBLogoPictureBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AUIBLogoPictureBox.BackColor = System.Drawing.Color.Transparent;
            this.AUIBLogoPictureBox.Image = global::SMS_CSC235.Properties.Resources.AUIB_red_logo;
            this.AUIBLogoPictureBox.ImageRotate = 0F;
            this.AUIBLogoPictureBox.Location = new System.Drawing.Point(25, 52);
            this.AUIBLogoPictureBox.Name = "AUIBLogoPictureBox";
            this.AUIBLogoPictureBox.Size = new System.Drawing.Size(376, 360);
            this.AUIBLogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AUIBLogoPictureBox.TabIndex = 0;
            this.AUIBLogoPictureBox.TabStop = false;
            this.AUIBLogoPictureBox.UseTransparentBackground = true;
            this.AUIBLogoPictureBox.Click += new System.EventHandler(this.guna2PictureBox1_Click);
            // 
            // ShowPasswordToggleSwitch
            // 
            this.ShowPasswordToggleSwitch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ShowPasswordToggleSwitch.Animated = true;
            this.ShowPasswordToggleSwitch.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.ShowPasswordToggleSwitch.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.ShowPasswordToggleSwitch.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.ShowPasswordToggleSwitch.CheckedState.InnerColor = System.Drawing.Color.White;
            this.ShowPasswordToggleSwitch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowPasswordToggleSwitch.Location = new System.Drawing.Point(444, 263);
            this.ShowPasswordToggleSwitch.Name = "ShowPasswordToggleSwitch";
            this.ShowPasswordToggleSwitch.Size = new System.Drawing.Size(35, 20);
            this.ShowPasswordToggleSwitch.TabIndex = 3;
            this.ShowPasswordToggleSwitch.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ShowPasswordToggleSwitch.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.ShowPasswordToggleSwitch.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.ShowPasswordToggleSwitch.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.ShowPasswordToggleSwitch.CheckedChanged += new System.EventHandler(this.ShowPasswordToggleSwitch_CheckedChanged);
            // 
            // ShowPasswordLabel
            // 
            this.ShowPasswordLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ShowPasswordLabel.AutoSize = true;
            this.ShowPasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowPasswordLabel.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ShowPasswordLabel.Location = new System.Drawing.Point(485, 263);
            this.ShowPasswordLabel.Name = "ShowPasswordLabel";
            this.ShowPasswordLabel.Size = new System.Drawing.Size(139, 22);
            this.ShowPasswordLabel.TabIndex = 4;
            this.ShowPasswordLabel.Text = "Show Password";
            this.ShowPasswordLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ShowPasswordLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // RememberMeCheckBox
            // 
            this.RememberMeCheckBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.RememberMeCheckBox.Animated = true;
            this.RememberMeCheckBox.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.RememberMeCheckBox.CheckedState.BorderRadius = 2;
            this.RememberMeCheckBox.CheckedState.BorderThickness = 0;
            this.RememberMeCheckBox.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.RememberMeCheckBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RememberMeCheckBox.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.RememberMeCheckBox.Location = new System.Drawing.Point(606, 263);
            this.RememberMeCheckBox.Name = "RememberMeCheckBox";
            this.RememberMeCheckBox.Size = new System.Drawing.Size(20, 20);
            this.RememberMeCheckBox.TabIndex = 5;
            this.RememberMeCheckBox.Text = "guna2CustomCheckBox1";
            this.RememberMeCheckBox.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.RememberMeCheckBox.UncheckedState.BorderRadius = 2;
            this.RememberMeCheckBox.UncheckedState.BorderThickness = 0;
            this.RememberMeCheckBox.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.RememberMeCheckBox.Click += new System.EventHandler(this.RememberMeCheckBox_Click);
            // 
            // RememberMeLabel
            // 
            this.RememberMeLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.RememberMeLabel.AutoSize = true;
            this.RememberMeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RememberMeLabel.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.RememberMeLabel.Location = new System.Drawing.Point(632, 263);
            this.RememberMeLabel.Name = "RememberMeLabel";
            this.RememberMeLabel.Size = new System.Drawing.Size(126, 22);
            this.RememberMeLabel.TabIndex = 6;
            this.RememberMeLabel.Text = "Remember Me";
            // 
            // LoginButton
            // 
            this.LoginButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LoginButton.BorderRadius = 9;
            this.LoginButton.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.LoginButton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.LoginButton.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.LoginButton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.LoginButton.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.LoginButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LoginButton.ForeColor = System.Drawing.Color.White;
            this.LoginButton.Location = new System.Drawing.Point(522, 364);
            this.LoginButton.Name = "LoginButton";
            this.LoginButton.Size = new System.Drawing.Size(115, 37);
            this.LoginButton.TabIndex = 7;
            this.LoginButton.Text = "Login";
            this.LoginButton.Click += new System.EventHandler(this.btnLogin);
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.WelcomeLabel.AutoSize = true;
            this.WelcomeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WelcomeLabel.ForeColor = System.Drawing.Color.DimGray;
            this.WelcomeLabel.Location = new System.Drawing.Point(426, 88);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(422, 55);
            this.WelcomeLabel.TabIndex = 8;
            this.WelcomeLabel.Text = "Welcome to SMS!";
            this.WelcomeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.WelcomeLabel.Click += new System.EventHandler(this.label3_Click);
            // 
            // guna2ContextMenuStrip1
            // 
            this.guna2ContextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.guna2ContextMenuStrip1.Name = "guna2ContextMenuStrip1";
            this.guna2ContextMenuStrip1.RenderStyle.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.guna2ContextMenuStrip1.RenderStyle.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2ContextMenuStrip1.RenderStyle.ColorTable = null;
            this.guna2ContextMenuStrip1.RenderStyle.RoundedEdges = true;
            this.guna2ContextMenuStrip1.RenderStyle.SelectionArrowColor = System.Drawing.Color.White;
            this.guna2ContextMenuStrip1.RenderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2ContextMenuStrip1.RenderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.guna2ContextMenuStrip1.RenderStyle.SeparatorColor = System.Drawing.Color.Gainsboro;
            this.guna2ContextMenuStrip1.RenderStyle.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2ContextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.guna2ControlBox1);
            this.panel1.Controls.Add(this.guna2ControlBox2);
            this.panel1.Location = new System.Drawing.Point(721, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(53, 29);
            this.panel1.TabIndex = 12;
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.Animated = true;
            this.guna2ControlBox1.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.guna2ControlBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2ControlBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.HoverState.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.guna2ControlBox1.IconColor = System.Drawing.Color.Gray;
            this.guna2ControlBox1.Location = new System.Drawing.Point(10, 5);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.Size = new System.Drawing.Size(14, 19);
            this.guna2ControlBox1.TabIndex = 13;
            // 
            // guna2ControlBox2
            // 
            this.guna2ControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox2.Animated = true;
            this.guna2ControlBox2.BorderRadius = 2;
            this.guna2ControlBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2ControlBox2.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox2.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox2.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox2.HoverState.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.guna2ControlBox2.IconColor = System.Drawing.Color.Gray;
            this.guna2ControlBox2.Location = new System.Drawing.Point(30, 5);
            this.guna2ControlBox2.Name = "guna2ControlBox2";
            this.guna2ControlBox2.Size = new System.Drawing.Size(12, 19);
            this.guna2ControlBox2.TabIndex = 12;
            // 
            // comboBoxRole
            // 
            this.comboBoxRole.AutoRoundedCorners = true;
            this.comboBoxRole.BackColor = System.Drawing.Color.Transparent;
            this.comboBoxRole.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(218)))), ((int)(((byte)(223)))));
            this.comboBoxRole.BorderRadius = 17;
            this.comboBoxRole.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxRole.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.comboBoxRole.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.comboBoxRole.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxRole.ForeColor = System.Drawing.Color.DimGray;
            this.comboBoxRole.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.comboBoxRole.ItemHeight = 30;
            this.comboBoxRole.Items.AddRange(new object[] {
            "Admin",
            "Teacher"});
            this.comboBoxRole.Location = new System.Drawing.Point(448, 305);
            this.comboBoxRole.Name = "comboBoxRole";
            this.comboBoxRole.Size = new System.Drawing.Size(168, 36);
            this.comboBoxRole.TabIndex = 13;
            this.comboBoxRole.TextOffset = new System.Drawing.Point(20, 0);
            this.comboBoxRole.SelectedIndexChanged += new System.EventHandler(this.guna2ComboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(632, 315);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 22);
            this.label1.TabIndex = 14;
            this.label1.Text = "Select a Role";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(455, 313);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(17, 20);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 15;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.UseTransparentBackground = true;
            // 
            // Login
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(786, 452);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxRole);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.WelcomeLabel);
            this.Controls.Add(this.LoginButton);
            this.Controls.Add(this.RememberMeLabel);
            this.Controls.Add(this.RememberMeCheckBox);
            this.Controls.Add(this.ShowPasswordLabel);
            this.Controls.Add(this.ShowPasswordToggleSwitch);
            this.Controls.Add(this.PasswordTextBox);
            this.Controls.Add(this.UsernameTextBox);
            this.Controls.Add(this.AUIBLogoPictureBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Login_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.AUIBLogoPictureBox)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion


        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2ShadowForm guna2ShadowForm1;
        private Guna.UI2.WinForms.Guna2PictureBox AUIBLogoPictureBox;
        private Guna.UI2.WinForms.Guna2TextBox UsernameTextBox;
        private Guna.UI2.WinForms.Guna2ColorTransition guna2ColorTransition1;
        private Guna.UI2.WinForms.Guna2TextBox PasswordTextBox;
        private System.Windows.Forms.Label ShowPasswordLabel;
        private Guna.UI2.WinForms.Guna2ToggleSwitch ShowPasswordToggleSwitch;
        private Guna.UI2.WinForms.Guna2CustomCheckBox RememberMeCheckBox;
        private System.Windows.Forms.Label RememberMeLabel;
        private Guna.UI2.WinForms.Guna2Button LoginButton;
        private System.Windows.Forms.Label WelcomeLabel;
        private Guna.UI2.WinForms.Guna2ContextMenuStrip guna2ContextMenuStrip1;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox2;
        private Guna.UI2.WinForms.Guna2ComboBox comboBoxRole;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
    }
}

