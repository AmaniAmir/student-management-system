﻿using Guna.UI2.WinForms;
using Guna.UI2.WinForms.Suite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMS_CSC235
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.RememberMe)
            {
                UsernameTextBox.Text = Properties.Settings.Default.Username;
                PasswordTextBox.Text = Properties.Settings.Default.Password;
                RememberMeCheckBox.Checked = true;
            }
        }

        private void PasswordTextbox(object sender, EventArgs e)
        {
            PasswordTextBox.PasswordChar = '*';
        }

        private void ShowPasswordToggleSwitch_CheckedChanged(object sender, EventArgs e)
        {
            if (ShowPasswordToggleSwitch.Checked)
            {
                PasswordTextBox.PasswordChar = '\0';
            }
            else
            {
                PasswordTextBox.PasswordChar = '*';
            }
        }

        private void btnLogin(object sender, EventArgs e)
        {
            if (comboBoxRole.SelectedItem == null)
            {
                MessageBox.Show("Please select a role before logging in!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string selectedRole = comboBoxRole.SelectedItem.ToString();

            string correctUsername = "admin";
            string correctPassword = "1234";

            string enteredUsername = UsernameTextBox.Text;
            string enteredPassword = PasswordTextBox.Text;

            if (enteredUsername == correctUsername && enteredPassword == correctPassword)
            {
                if (RememberMeCheckBox.Checked)
                {
                    Properties.Settings.Default.Username = enteredUsername;
                    Properties.Settings.Default.Password = enteredPassword;
                    Properties.Settings.Default.RememberMe = true;
                }
                else
                {
                    Properties.Settings.Default.Username = "";
                    Properties.Settings.Default.Password = "";
                    Properties.Settings.Default.RememberMe = false;
                }
                Properties.Settings.Default.Save();

                MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();

                Dashboard dashboard = new Dashboard();
                dashboard.LoggedInRole = selectedRole;
                dashboard.WindowState = this.WindowState;
                dashboard.Show();
            }
            else
            {
                MessageBox.Show("Invalid Username or Password!", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }



        //-------------------------------------------------------------


        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {
        }

        private void guna2ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void RememberMeCheckBox_Click(object sender, EventArgs e)
        {
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
        }
    }
}
