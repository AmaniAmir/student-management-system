﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_CSC235.Models
{
    public class cStudent
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Major { get; set; }
        public float GPA { get; set; }
        public DateTime Birthday { get; set; }
        public string Phone { get; set; }
    }
}
