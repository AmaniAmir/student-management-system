﻿namespace SMS_CSC235
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Panel panelControlBox;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.MaximizeControlBox = new Guna.UI2.WinForms.Guna2ControlBox();
            this.MinimizeControlBox = new Guna.UI2.WinForms.Guna2ControlBox();
            this.ExitControlBox = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ShadowForm1 = new Guna.UI2.WinForms.Guna2ShadowForm(this.components);
            this.guna2ColorTransition1 = new Guna.UI2.WinForms.Guna2ColorTransition(this.components);
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnViewStudent = new Guna.UI2.WinForms.Guna2Button();
            this.btnDeleteStudent = new Guna.UI2.WinForms.Guna2Button();
            this.btnAddStudent = new Guna.UI2.WinForms.Guna2Button();
            this.btnEditStudent = new Guna.UI2.WinForms.Guna2Button();
            this.btnSearchStudent = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.SlidePictureBox = new Guna.UI2.WinForms.Guna2PictureBox();
            this.panelContainer = new System.Windows.Forms.Panel();
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            panelControlBox = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SlidePictureBox)).BeginInit();
            this.panelContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelControlBox
            // 
            panelControlBox.Dock = System.Windows.Forms.DockStyle.Fill;
            panelControlBox.Location = new System.Drawing.Point(0, 6);
            panelControlBox.Name = "panelControlBox";
            panelControlBox.Size = new System.Drawing.Size(597, 438);
            panelControlBox.TabIndex = 15;
            panelControlBox.Paint += new System.Windows.Forms.PaintEventHandler(this.panelControlBox_Paint);
            // 
            // MaximizeControlBox
            // 
            this.MaximizeControlBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MaximizeControlBox.Animated = true;
            this.MaximizeControlBox.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MaximizeBox;
            this.MaximizeControlBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MaximizeControlBox.FillColor = System.Drawing.Color.Transparent;
            this.MaximizeControlBox.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.MaximizeControlBox.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.MaximizeControlBox.HoverState.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.MaximizeControlBox.IconColor = System.Drawing.Color.Gray;
            this.MaximizeControlBox.Location = new System.Drawing.Point(760, 12);
            this.MaximizeControlBox.Name = "MaximizeControlBox";
            this.MaximizeControlBox.Size = new System.Drawing.Size(13, 19);
            this.MaximizeControlBox.TabIndex = 14;
            // 
            // MinimizeControlBox
            // 
            this.MinimizeControlBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MinimizeControlBox.Animated = true;
            this.MinimizeControlBox.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.MinimizeControlBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MinimizeControlBox.FillColor = System.Drawing.Color.Transparent;
            this.MinimizeControlBox.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.MinimizeControlBox.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.MinimizeControlBox.HoverState.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.MinimizeControlBox.IconColor = System.Drawing.Color.Gray;
            this.MinimizeControlBox.Location = new System.Drawing.Point(740, 12);
            this.MinimizeControlBox.Name = "MinimizeControlBox";
            this.MinimizeControlBox.Size = new System.Drawing.Size(14, 19);
            this.MinimizeControlBox.TabIndex = 13;
            // 
            // ExitControlBox
            // 
            this.ExitControlBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ExitControlBox.Animated = true;
            this.ExitControlBox.BorderRadius = 2;
            this.ExitControlBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitControlBox.FillColor = System.Drawing.Color.Transparent;
            this.ExitControlBox.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.ExitControlBox.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.ExitControlBox.HoverState.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.ExitControlBox.IconColor = System.Drawing.Color.Gray;
            this.ExitControlBox.Location = new System.Drawing.Point(779, 12);
            this.ExitControlBox.Name = "ExitControlBox";
            this.ExitControlBox.Size = new System.Drawing.Size(12, 19);
            this.ExitControlBox.TabIndex = 12;
            // 
            // guna2ShadowForm1
            // 
            this.guna2ShadowForm1.TargetForm = this;
            // 
            // guna2ColorTransition1
            // 
            this.guna2ColorTransition1.ColorArray = new System.Drawing.Color[] {
        System.Drawing.Color.Red,
        System.Drawing.Color.Blue,
        System.Drawing.Color.Orange};
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnViewStudent);
            this.panel1.Controls.Add(this.btnDeleteStudent);
            this.panel1.Controls.Add(this.btnAddStudent);
            this.panel1.Controls.Add(this.btnEditStudent);
            this.panel1.Controls.Add(this.btnSearchStudent);
            this.panel1.Controls.Add(this.guna2PictureBox1);
            this.panel1.Controls.Add(this.SlidePictureBox);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(197, 450);
            this.panel1.TabIndex = 15;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnViewStudent
            // 
            this.btnViewStudent.BackColor = System.Drawing.Color.Transparent;
            this.btnViewStudent.BorderRadius = 22;
            this.btnViewStudent.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnViewStudent.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnViewStudent.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.btnViewStudent.CheckedState.Image = global::SMS_CSC235.Properties.Resources.icons8_view_24;
            this.btnViewStudent.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnViewStudent.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnViewStudent.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnViewStudent.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnViewStudent.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.btnViewStudent.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewStudent.ForeColor = System.Drawing.Color.White;
            this.btnViewStudent.Image = ((System.Drawing.Image)(resources.GetObject("btnViewStudent.Image")));
            this.btnViewStudent.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnViewStudent.ImageOffset = new System.Drawing.Point(10, 0);
            this.btnViewStudent.Location = new System.Drawing.Point(37, 165);
            this.btnViewStudent.Name = "btnViewStudent";
            this.btnViewStudent.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnViewStudent.Size = new System.Drawing.Size(163, 43);
            this.btnViewStudent.TabIndex = 2;
            this.btnViewStudent.Text = "       View Student";
            this.btnViewStudent.UseTransparentBackground = true;
            this.btnViewStudent.CheckedChanged += new System.EventHandler(this.ViewStudentButton_CheckedChanged);
            this.btnViewStudent.Click += new System.EventHandler(this.ViewStudentButton_Click);
            // 
            // btnDeleteStudent
            // 
            this.btnDeleteStudent.BackColor = System.Drawing.Color.Transparent;
            this.btnDeleteStudent.BorderRadius = 22;
            this.btnDeleteStudent.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnDeleteStudent.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnDeleteStudent.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.btnDeleteStudent.CheckedState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnDeleteStudent.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDeleteStudent.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnDeleteStudent.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDeleteStudent.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnDeleteStudent.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.btnDeleteStudent.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnDeleteStudent.ForeColor = System.Drawing.Color.White;
            this.btnDeleteStudent.Image = ((System.Drawing.Image)(resources.GetObject("btnDeleteStudent.Image")));
            this.btnDeleteStudent.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnDeleteStudent.ImageOffset = new System.Drawing.Point(10, 0);
            this.btnDeleteStudent.Location = new System.Drawing.Point(37, 372);
            this.btnDeleteStudent.Name = "btnDeleteStudent";
            this.btnDeleteStudent.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnDeleteStudent.Size = new System.Drawing.Size(163, 43);
            this.btnDeleteStudent.TabIndex = 20;
            this.btnDeleteStudent.Text = "       Delete Student";
            this.btnDeleteStudent.UseTransparentBackground = true;
            this.btnDeleteStudent.CheckedChanged += new System.EventHandler(this.ViewStudentButton_CheckedChanged);
            this.btnDeleteStudent.Click += new System.EventHandler(this.guna2Button4_Click);
            // 
            // btnAddStudent
            // 
            this.btnAddStudent.BackColor = System.Drawing.Color.Transparent;
            this.btnAddStudent.BorderRadius = 22;
            this.btnAddStudent.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnAddStudent.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnAddStudent.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.btnAddStudent.CheckedState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnAddStudent.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnAddStudent.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnAddStudent.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnAddStudent.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnAddStudent.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.btnAddStudent.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddStudent.ForeColor = System.Drawing.Color.White;
            this.btnAddStudent.Image = ((System.Drawing.Image)(resources.GetObject("btnAddStudent.Image")));
            this.btnAddStudent.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnAddStudent.ImageOffset = new System.Drawing.Point(10, 0);
            this.btnAddStudent.Location = new System.Drawing.Point(37, 303);
            this.btnAddStudent.Name = "btnAddStudent";
            this.btnAddStudent.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnAddStudent.Size = new System.Drawing.Size(163, 43);
            this.btnAddStudent.TabIndex = 19;
            this.btnAddStudent.Text = "     Add Student";
            this.btnAddStudent.UseTransparentBackground = true;
            this.btnAddStudent.CheckedChanged += new System.EventHandler(this.ViewStudentButton_CheckedChanged);
            // 
            // btnEditStudent
            // 
            this.btnEditStudent.BackColor = System.Drawing.Color.Transparent;
            this.btnEditStudent.BorderRadius = 22;
            this.btnEditStudent.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnEditStudent.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnEditStudent.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.btnEditStudent.CheckedState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnEditStudent.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnEditStudent.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnEditStudent.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnEditStudent.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnEditStudent.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.btnEditStudent.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnEditStudent.ForeColor = System.Drawing.Color.White;
            this.btnEditStudent.Image = ((System.Drawing.Image)(resources.GetObject("btnEditStudent.Image")));
            this.btnEditStudent.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnEditStudent.ImageOffset = new System.Drawing.Point(10, 0);
            this.btnEditStudent.Location = new System.Drawing.Point(37, 234);
            this.btnEditStudent.Name = "btnEditStudent";
            this.btnEditStudent.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnEditStudent.Size = new System.Drawing.Size(163, 43);
            this.btnEditStudent.TabIndex = 18;
            this.btnEditStudent.Text = "    Edit Student";
            this.btnEditStudent.UseTransparentBackground = true;
            this.btnEditStudent.CheckedChanged += new System.EventHandler(this.ViewStudentButton_CheckedChanged);
            this.btnEditStudent.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // btnSearchStudent
            // 
            this.btnSearchStudent.BackColor = System.Drawing.Color.Transparent;
            this.btnSearchStudent.BorderRadius = 22;
            this.btnSearchStudent.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnSearchStudent.Checked = true;
            this.btnSearchStudent.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnSearchStudent.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.btnSearchStudent.CheckedState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnSearchStudent.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSearchStudent.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSearchStudent.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSearchStudent.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSearchStudent.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.btnSearchStudent.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnSearchStudent.ForeColor = System.Drawing.Color.White;
            this.btnSearchStudent.Image = ((System.Drawing.Image)(resources.GetObject("btnSearchStudent.Image")));
            this.btnSearchStudent.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSearchStudent.ImageOffset = new System.Drawing.Point(10, 0);
            this.btnSearchStudent.Location = new System.Drawing.Point(37, 96);
            this.btnSearchStudent.Name = "btnSearchStudent";
            this.btnSearchStudent.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnSearchStudent.Size = new System.Drawing.Size(163, 43);
            this.btnSearchStudent.TabIndex = 17;
            this.btnSearchStudent.Text = "Home";
            this.btnSearchStudent.UseTransparentBackground = true;
            this.btnSearchStudent.CheckedChanged += new System.EventHandler(this.ViewStudentButton_CheckedChanged);
            this.btnSearchStudent.Click += new System.EventHandler(this.btnSearchStudent_Click_1);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = global::SMS_CSC235.Properties.Resources.AUIB_red_logo;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(72, 21);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(62, 55);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 0;
            this.guna2PictureBox1.TabStop = false;
            // 
            // SlidePictureBox
            // 
            this.SlidePictureBox.Image = global::SMS_CSC235.Properties.Resources.Screenshot_2025_02_09_0156081;
            this.SlidePictureBox.ImageRotate = 0F;
            this.SlidePictureBox.Location = new System.Drawing.Point(179, 67);
            this.SlidePictureBox.Name = "SlidePictureBox";
            this.SlidePictureBox.Size = new System.Drawing.Size(23, 99);
            this.SlidePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SlidePictureBox.TabIndex = 16;
            this.SlidePictureBox.TabStop = false;
            this.SlidePictureBox.Click += new System.EventHandler(this.guna2PictureBox2_Click);
            // 
            // panelContainer
            // 
            this.panelContainer.Controls.Add(panelControlBox);
            this.panelContainer.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelContainer.Location = new System.Drawing.Point(197, 0);
            this.panelContainer.Name = "panelContainer";
            this.panelContainer.Padding = new System.Windows.Forms.Padding(0, 6, 3, 6);
            this.panelContainer.Size = new System.Drawing.Size(600, 450);
            this.panelContainer.TabIndex = 16;
            this.panelContainer.Paint += new System.Windows.Forms.PaintEventHandler(this.panelContainer_Paint);
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.BorderRadius = 50;
            this.guna2Elipse2.TargetControl = this.panelContainer;
            // 
            // Dashboard
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.panelContainer);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.MaximizeControlBox);
            this.Controls.Add(this.MinimizeControlBox);
            this.Controls.Add(this.ExitControlBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Dashboard_FormClosing);
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SlidePictureBox)).EndInit();
            this.panelContainer.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ControlBox MaximizeControlBox;
        private Guna.UI2.WinForms.Guna2ControlBox MinimizeControlBox;
        private Guna.UI2.WinForms.Guna2ControlBox ExitControlBox;
        private Guna.UI2.WinForms.Guna2ShadowForm guna2ShadowForm1;
        private Guna.UI2.WinForms.Guna2ColorTransition guna2ColorTransition1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2Button btnViewStudent;
        private Guna.UI2.WinForms.Guna2PictureBox SlidePictureBox;
        private Guna.UI2.WinForms.Guna2Button btnAddStudent;
        private Guna.UI2.WinForms.Guna2Button btnSearchStudent;
        private Guna.UI2.WinForms.Guna2Button btnDeleteStudent;
        public System.Windows.Forms.Panel panelContainer;
        private Guna.UI2.WinForms.Guna2Button btnEditStudent;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
    }
}