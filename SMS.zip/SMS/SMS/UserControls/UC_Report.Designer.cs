﻿namespace SMS_CSC235.UserControls
{
    partial class UC_Report
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Report));
            this.btnSaveReport = new Guna.UI2.WinForms.Guna2Button();
            this.btnPrintReport = new Guna.UI2.WinForms.Guna2Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.MinimizeControlBox = new Guna.UI2.WinForms.Guna2ControlBox();
            this.ExitControlBox = new Guna.UI2.WinForms.Guna2ControlBox();
            this.label1 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSaveReport
            // 
            this.btnSaveReport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSaveReport.BorderRadius = 9;
            this.btnSaveReport.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSaveReport.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSaveReport.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSaveReport.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSaveReport.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.btnSaveReport.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveReport.ForeColor = System.Drawing.Color.White;
            this.btnSaveReport.Location = new System.Drawing.Point(106, 338);
            this.btnSaveReport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSaveReport.Name = "btnSaveReport";
            this.btnSaveReport.Size = new System.Drawing.Size(256, 103);
            this.btnSaveReport.TabIndex = 27;
            this.btnSaveReport.Text = "Save";
            this.btnSaveReport.Click += new System.EventHandler(this.btnSaveReport_Click);
            // 
            // btnPrintReport
            // 
            this.btnPrintReport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPrintReport.BorderRadius = 9;
            this.btnPrintReport.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnPrintReport.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnPrintReport.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnPrintReport.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnPrintReport.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.btnPrintReport.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintReport.ForeColor = System.Drawing.Color.White;
            this.btnPrintReport.Location = new System.Drawing.Point(538, 338);
            this.btnPrintReport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPrintReport.Name = "btnPrintReport";
            this.btnPrintReport.Size = new System.Drawing.Size(240, 103);
            this.btnPrintReport.TabIndex = 28;
            this.btnPrintReport.Text = "Print";
            this.btnPrintReport.Click += new System.EventHandler(this.btnPrintReport_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.MinimizeControlBox);
            this.panel1.Controls.Add(this.ExitControlBox);
            this.panel1.Location = new System.Drawing.Point(816, 5);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(80, 45);
            this.panel1.TabIndex = 29;
            // 
            // MinimizeControlBox
            // 
            this.MinimizeControlBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MinimizeControlBox.Animated = true;
            this.MinimizeControlBox.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.MinimizeControlBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MinimizeControlBox.FillColor = System.Drawing.Color.Transparent;
            this.MinimizeControlBox.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.MinimizeControlBox.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.MinimizeControlBox.HoverState.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.MinimizeControlBox.IconColor = System.Drawing.Color.Gray;
            this.MinimizeControlBox.Location = new System.Drawing.Point(15, 8);
            this.MinimizeControlBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MinimizeControlBox.Name = "MinimizeControlBox";
            this.MinimizeControlBox.Size = new System.Drawing.Size(21, 29);
            this.MinimizeControlBox.TabIndex = 13;
            // 
            // ExitControlBox
            // 
            this.ExitControlBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ExitControlBox.Animated = true;
            this.ExitControlBox.BorderRadius = 2;
            this.ExitControlBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitControlBox.FillColor = System.Drawing.Color.Transparent;
            this.ExitControlBox.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.ExitControlBox.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.ExitControlBox.HoverState.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.ExitControlBox.IconColor = System.Drawing.Color.Gray;
            this.ExitControlBox.Location = new System.Drawing.Point(45, 8);
            this.ExitControlBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ExitControlBox.Name = "ExitControlBox";
            this.ExitControlBox.Size = new System.Drawing.Size(18, 29);
            this.ExitControlBox.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.label1.Location = new System.Drawing.Point(256, 148);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(383, 55);
            this.label1.TabIndex = 30;
            this.label1.Text = "Generate Report";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 654);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.toolStrip1.Size = new System.Drawing.Size(900, 38);
            this.toolStrip1.TabIndex = 31;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.DoubleClickEnabled = true;
            this.toolStripButton1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(42, 33);
            this.toolStripButton1.Text = "File";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.DoubleClickEnabled = true;
            this.toolStripButton2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(53, 33);
            this.toolStripButton2.Text = "Help";
            // 
            // UC_Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnPrintReport);
            this.Controls.Add(this.btnSaveReport);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "UC_Report";
            this.Size = new System.Drawing.Size(900, 692);
            this.Load += new System.EventHandler(this.UC_Report_Load);
            this.panel1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button btnSaveReport;
        private Guna.UI2.WinForms.Guna2Button btnPrintReport;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2ControlBox MinimizeControlBox;
        private Guna.UI2.WinForms.Guna2ControlBox ExitControlBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
    }
}
