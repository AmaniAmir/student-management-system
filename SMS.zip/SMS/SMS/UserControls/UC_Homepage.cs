﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMS_CSC235.UserControls
{
    public partial class UC_Homepage : UserControl
    {
        public UC_Homepage()
        {
            InitializeComponent();
        }

        private void HelpToolStrip(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.Google.com");
        }

        private void FileToolStrip(object sender, EventArgs e)
        {
            MessageBox.Show("Coming Soon!");
        }


        //------------------------------------------------------------------


        private void UC_SearchStudent_Load(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }
    }
}
