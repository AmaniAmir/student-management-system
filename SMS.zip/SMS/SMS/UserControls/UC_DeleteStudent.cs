﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMS_CSC235.UserControls
{
    public partial class UC_DeleteStudent : UserControl
    {
        private Dashboard dashboard;

        public UC_DeleteStudent(Dashboard form)
        {
            InitializeComponent();
            dashboard = form;
        }

        private void btnDelete(object sender, EventArgs e)
        {
            if (dashboard.LoggedInRole == "Teacher")
            {
                MessageBox.Show("This feature is only available for Admins.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (int.TryParse(DeleteStudentTextBox.Text.Trim(), out int studentID))
            {
                dashboard.DeleteStudent(studentID);
                DeleteStudentTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid numeric Student ID.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DeleteStudentTextBox.Clear();
            }
        }

        private void HelpToolStrip(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.Google.com");
        }

        private void FileToolStrip(object sender, EventArgs e)
        {
            MessageBox.Show("Coming Soon!");
        }


        //-------------------------------------------------------------------------------


        private void UC_DeleteStudent_Load(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }
    }
}
