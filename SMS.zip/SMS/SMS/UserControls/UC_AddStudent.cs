﻿using SMS_CSC235.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace SMS_CSC235.UserControls
{
    public partial class UC_AddStudent : UserControl
    {
        private Dashboard dashboard;

        public UC_AddStudent(Dashboard form)
        {
            InitializeComponent();
            dashboard = form;
        }
        
        private void btnAdd(object sender, EventArgs e)
        {
            if (dashboard.LoggedInRole == "Teacher")
            {
                MessageBox.Show("This feature is only available for Admins.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(AddIDTextbox.Text) ||
                string.IsNullOrWhiteSpace(AddNameTextbox.Text) ||
                string.IsNullOrWhiteSpace(AddMajorTextbox.Text) ||
                string.IsNullOrWhiteSpace(AddGPATextbox.Text) ||
                string.IsNullOrWhiteSpace(AddPhoneTextbox.Text))
            {
                MessageBox.Show("All fields are required! Please fill in all details.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(AddIDTextbox.Text, out int studentID))
            {
                MessageBox.Show("Student ID must be numeric!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!float.TryParse(AddGPATextbox.Text, out float studentGPA))
            {
                MessageBox.Show("Student GPA must be numeric!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (studentGPA < 0 || studentGPA > 4)
            {
                MessageBox.Show("Please enter a valid numeric Student GPA!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (BirthdayDateTimePicker.Value.Year < 1900)
            {
                MessageBox.Show("Please select a valid birthday!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            cStudent newStudent = new cStudent
            {
                ID = studentID,
                Name = AddNameTextbox.Text.Trim(),
                Major = AddMajorTextbox.Text.Trim(),
                GPA = studentGPA,
                Birthday = BirthdayDateTimePicker.Value,
                Phone = AddPhoneTextbox.Text.Trim()
            };

            dashboard.AddStudent(newStudent);

            AddIDTextbox.Clear();
            AddNameTextbox.Clear();
            AddMajorTextbox.Clear();
            AddGPATextbox.Clear();
            AddPhoneTextbox.Clear();
            BirthdayDateTimePicker.Value = new DateTime(1800, 1, 1);
        }

        private void HelpToolStrip(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.Google.com");
        }

        private void FileToolStrip(object sender, EventArgs e)
        {
            MessageBox.Show("Coming Soon!");
        }


        //-----------------------------------------------------------------------------


        private void BirthdayDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
        }

        private void DeleteStudentTextBox_TextChanged(object sender, EventArgs e)
        {
        }

        private void guna2TextBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void guna2TextBox4_TextChanged(object sender, EventArgs e)
        {
        }

        private void BirthdayLabell(object sender, EventArgs e)
        {
        }

        private void guna2PictureBox2_Click(object sender, EventArgs e)
        {
        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {
        }

        private void UC_AddStudent_Load(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void guna2TextBox3_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
