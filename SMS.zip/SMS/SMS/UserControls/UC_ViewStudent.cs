﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using SMS_CSC235.Models;


namespace SMS_CSC235.UserControls
{
    public partial class UC_ViewStudent : UserControl
    {
        public Dashboard dashboard;

        public UC_ViewStudent(Dashboard form)
        {
            InitializeComponent();
            dashboard = form;
            LoadStudentData();
        }

        private void LoadStudentData()
        { 
            DataGridView.DataSource = new BindingSource { DataSource = dashboard.StudentData };
            
            foreach (DataGridViewColumn column in DataGridView.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.Automatic;
            }
            DataGridView.Columns["Birthday"].DefaultCellStyle.Format = "yyyy/MM/dd";
        }
        
        private void SearchStudentTextBox(object sender, EventArgs e)
        {
            DataGridView.DataSource = dashboard.SearchStudents(CriteriaTextBox.Text.Trim());
        }

        private void HelpToolStrip(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.Google.com");
        }

        private void FileToolStrip(object sender, EventArgs e)
        {
            MessageBox.Show("Coming Soon!");
        }

        private void generateReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (DataGridView.SelectedRows.Count == 0)
                return;

            var row = DataGridView.SelectedRows[0];
            var student = new cStudent
            {
                ID = Convert.ToInt32(row.Cells["ID"].Value),
                Name = row.Cells["Name"].Value.ToString(),
                Major = row.Cells["Major"].Value.ToString(),
                GPA = float.Parse(row.Cells["GPA"].Value.ToString()),
                Birthday = Convert.ToDateTime(row.Cells["Birthday"].Value),
                Phone = row.Cells["Phone"].Value.ToString()
            };

            UC_Report reportUC = new UC_Report(student);
            dashboard.panelContainer.Controls.Clear();
            dashboard.panelContainer.Controls.Add(reportUC);
            reportUC.Dock = DockStyle.Fill;
        }




        //------------------------------------------------------------------------------------------------


        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void panelControlBox_Paint(object sender, PaintEventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
