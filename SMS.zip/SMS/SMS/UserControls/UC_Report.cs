﻿using SMS_CSC235.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;


namespace SMS_CSC235.UserControls
{
    public partial class UC_Report : UserControl
    {
        private PrintDocument printDocument = new PrintDocument();
        private string reportContent;
        private cStudent Student;

        public UC_Report(cStudent selectedStudent)
        {
            InitializeComponent();
            Student = selectedStudent;
        }

        private string GenerateReportText()
        {
            return
                $"STUDENT REPORT\n\n" +
                $"ID       : {Student.ID}\n" +
                $"Name     : {Student.Name}\n" +
                $"Major    : {Student.Major}\n" +
                $"GPA      : {Student.GPA:F2}\n" +
                $"Birthday : {Student.Birthday:yyyy/MM/dd}\n" +
                $"Phone    : {Student.Phone}\n";
        }

        private void btnPrintReport_Click(object sender, EventArgs e)
        {
            reportContent = GenerateReportText();

            PrintPreviewDialog previewDialog = new PrintPreviewDialog();
            previewDialog.Document = printDocument;

            printDocument.PrintPage += PrintDocument_PrintPage;

            printDocument.PrintController = new FakePrintController();

            previewDialog.ShowDialog();
        }

        private void btnSaveReport_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt";
            saveFileDialog.FileName = $"Student_Report_{Student.ID}_{Student.Name.Replace(" ", "_")}.txt";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(saveFileDialog.FileName, GenerateReportText());
                MessageBox.Show("Report saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            Font font = new Font("Consolas", 12);
            Brush brush = Brushes.Black;
            float lineHeight = font.GetHeight(e.Graphics);
            float x = e.MarginBounds.Left;
            float y = e.MarginBounds.Top;

            foreach (string line in reportContent.Split('\n'))
            {
                e.Graphics.DrawString(line, font, brush, x, y);
                y += lineHeight;
            }
        }

        class FakePrintController : PrintController
        {
            public override void OnStartPrint(PrintDocument document, PrintEventArgs e) { }

            public override Graphics OnStartPage(PrintDocument document, PrintPageEventArgs e)
            {
                return Graphics.FromImage(new Bitmap(1, 1));
            }

            public override void OnEndPage(PrintDocument document, PrintPageEventArgs e) { }

            public override void OnEndPrint(PrintDocument document, PrintEventArgs e)
            {
                MessageBox.Show("Please connect to a printer", "Printer Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        // -----------------------------------------------------------------------------------


        private void UC_Report_Load(object sender, EventArgs e)
        {
        }
    }
}
