﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMS_CSC235.UserControls
{
    public partial class UC_EditStudent : UserControl
    {
        private Dashboard dashboard;

        public UC_EditStudent(Dashboard form)
        {
            InitializeComponent();
            dashboard = form;
        }

        private void btnSearchEdit(object sender, EventArgs e)
        {
            if (!int.TryParse(EditStudentTextBoxID.Text.Trim(), out int studentID))
            {
                MessageBox.Show("Please enter a valid numeric Student ID!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var student = dashboard.StudentData.FirstOrDefault(s => s.ID == studentID);

            if (student == null)
            {
                MessageBox.Show("Student not found! Please enter a valid ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show($"Student {student.Name} found! Redirecting to edit page.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                UC_EditStudent1 editStudentControl = new UC_EditStudent1(dashboard, student);
                dashboard.panelContainer.Controls.Clear();
                dashboard.panelContainer.Controls.Add(editStudentControl);
                editStudentControl.Dock = DockStyle.Fill;
            }
        }

        private void FileToolStrip(object sender, EventArgs e)
        {
            MessageBox.Show("Coming Soon!");
        }

        private void HelpToolStrip(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.Google.com");
        }


        //----------------------------------------------------------------------------------------------------


        private void DeleteStudentTextBox_TextChanged(object sender, EventArgs e)
        {
        }

        private void UC_EditStudent_Load(object sender, EventArgs e)
        {
        }
    }
}
