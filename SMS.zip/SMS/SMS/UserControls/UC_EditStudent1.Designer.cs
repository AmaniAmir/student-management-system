﻿namespace SMS_CSC235.UserControls
{
    partial class UC_EditStudent1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_EditStudent1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.MinimizeControlBox = new Guna.UI2.WinForms.Guna2ControlBox();
            this.ExitControlBox = new Guna.UI2.WinForms.Guna2ControlBox();
            this.label1 = new System.Windows.Forms.Label();
            this.EditNameTextbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.EditMajorTextbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.EditGPATextbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.EditPhoneTextbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.BirthdayLabel = new System.Windows.Forms.Label();
            this.EditBirthdayDateTimePicker = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.DeleteButton = new Guna.UI2.WinForms.Guna2Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.MinimizeControlBox);
            this.panel1.Controls.Add(this.ExitControlBox);
            this.panel1.Location = new System.Drawing.Point(544, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(53, 29);
            this.panel1.TabIndex = 2;
            // 
            // MinimizeControlBox
            // 
            this.MinimizeControlBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MinimizeControlBox.Animated = true;
            this.MinimizeControlBox.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.MinimizeControlBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MinimizeControlBox.FillColor = System.Drawing.Color.Transparent;
            this.MinimizeControlBox.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.MinimizeControlBox.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.MinimizeControlBox.HoverState.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.MinimizeControlBox.IconColor = System.Drawing.Color.Gray;
            this.MinimizeControlBox.Location = new System.Drawing.Point(10, 5);
            this.MinimizeControlBox.Name = "MinimizeControlBox";
            this.MinimizeControlBox.Size = new System.Drawing.Size(14, 19);
            this.MinimizeControlBox.TabIndex = 13;
            // 
            // ExitControlBox
            // 
            this.ExitControlBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ExitControlBox.Animated = true;
            this.ExitControlBox.BorderRadius = 2;
            this.ExitControlBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitControlBox.FillColor = System.Drawing.Color.Transparent;
            this.ExitControlBox.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.ExitControlBox.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.ExitControlBox.HoverState.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.ExitControlBox.IconColor = System.Drawing.Color.Gray;
            this.ExitControlBox.Location = new System.Drawing.Point(30, 5);
            this.ExitControlBox.Name = "ExitControlBox";
            this.ExitControlBox.Size = new System.Drawing.Size(12, 19);
            this.ExitControlBox.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.label1.Location = new System.Drawing.Point(201, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 37);
            this.label1.TabIndex = 13;
            this.label1.Text = "Edit Student";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // EditNameTextbox
            // 
            this.EditNameTextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditNameTextbox.Animated = true;
            this.EditNameTextbox.AutoRoundedCorners = true;
            this.EditNameTextbox.BorderRadius = 15;
            this.EditNameTextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.EditNameTextbox.DefaultText = "";
            this.EditNameTextbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.EditNameTextbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.EditNameTextbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.EditNameTextbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.EditNameTextbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.EditNameTextbox.FocusedState.FillColor = System.Drawing.Color.White;
            this.EditNameTextbox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditNameTextbox.ForeColor = System.Drawing.Color.DimGray;
            this.EditNameTextbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.EditNameTextbox.HoverState.FillColor = System.Drawing.Color.White;
            this.EditNameTextbox.IconLeft = ((System.Drawing.Image)(resources.GetObject("EditNameTextbox.IconLeft")));
            this.EditNameTextbox.IconLeftOffset = new System.Drawing.Point(7, 0);
            this.EditNameTextbox.Location = new System.Drawing.Point(38, 134);
            this.EditNameTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EditNameTextbox.MaxLength = 16;
            this.EditNameTextbox.Name = "EditNameTextbox";
            this.EditNameTextbox.PasswordChar = '\0';
            this.EditNameTextbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.EditNameTextbox.PlaceholderText = "Name";
            this.EditNameTextbox.SelectedText = "";
            this.EditNameTextbox.Size = new System.Drawing.Size(192, 33);
            this.EditNameTextbox.TabIndex = 14;
            this.EditNameTextbox.TextChanged += new System.EventHandler(this.AddNameTextbox_TextChanged);
            // 
            // EditMajorTextbox
            // 
            this.EditMajorTextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditMajorTextbox.Animated = true;
            this.EditMajorTextbox.AutoRoundedCorners = true;
            this.EditMajorTextbox.BorderRadius = 15;
            this.EditMajorTextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.EditMajorTextbox.DefaultText = "";
            this.EditMajorTextbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.EditMajorTextbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.EditMajorTextbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.EditMajorTextbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.EditMajorTextbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.EditMajorTextbox.FocusedState.FillColor = System.Drawing.Color.White;
            this.EditMajorTextbox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditMajorTextbox.ForeColor = System.Drawing.Color.DimGray;
            this.EditMajorTextbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.EditMajorTextbox.HoverState.FillColor = System.Drawing.Color.White;
            this.EditMajorTextbox.IconLeft = ((System.Drawing.Image)(resources.GetObject("EditMajorTextbox.IconLeft")));
            this.EditMajorTextbox.IconLeftOffset = new System.Drawing.Point(7, 0);
            this.EditMajorTextbox.Location = new System.Drawing.Point(357, 134);
            this.EditMajorTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EditMajorTextbox.MaxLength = 16;
            this.EditMajorTextbox.Name = "EditMajorTextbox";
            this.EditMajorTextbox.PasswordChar = '\0';
            this.EditMajorTextbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.EditMajorTextbox.PlaceholderText = "Major";
            this.EditMajorTextbox.SelectedText = "";
            this.EditMajorTextbox.Size = new System.Drawing.Size(192, 33);
            this.EditMajorTextbox.TabIndex = 16;
            // 
            // EditGPATextbox
            // 
            this.EditGPATextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditGPATextbox.Animated = true;
            this.EditGPATextbox.AutoRoundedCorners = true;
            this.EditGPATextbox.BorderRadius = 15;
            this.EditGPATextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.EditGPATextbox.DefaultText = "";
            this.EditGPATextbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.EditGPATextbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.EditGPATextbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.EditGPATextbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.EditGPATextbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.EditGPATextbox.FocusedState.FillColor = System.Drawing.Color.White;
            this.EditGPATextbox.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.EditGPATextbox.ForeColor = System.Drawing.Color.DimGray;
            this.EditGPATextbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.EditGPATextbox.HoverState.FillColor = System.Drawing.Color.White;
            this.EditGPATextbox.IconLeft = ((System.Drawing.Image)(resources.GetObject("EditGPATextbox.IconLeft")));
            this.EditGPATextbox.IconLeftOffset = new System.Drawing.Point(7, 0);
            this.EditGPATextbox.Location = new System.Drawing.Point(357, 203);
            this.EditGPATextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EditGPATextbox.MaxLength = 16;
            this.EditGPATextbox.Name = "EditGPATextbox";
            this.EditGPATextbox.PasswordChar = '\0';
            this.EditGPATextbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.EditGPATextbox.PlaceholderText = "GPA";
            this.EditGPATextbox.SelectedText = "";
            this.EditGPATextbox.Size = new System.Drawing.Size(192, 33);
            this.EditGPATextbox.TabIndex = 18;
            this.EditGPATextbox.TextChanged += new System.EventHandler(this.EditGPATextbox_TextChanged);
            // 
            // EditPhoneTextbox
            // 
            this.EditPhoneTextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditPhoneTextbox.Animated = true;
            this.EditPhoneTextbox.AutoRoundedCorners = true;
            this.EditPhoneTextbox.BorderRadius = 15;
            this.EditPhoneTextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.EditPhoneTextbox.DefaultText = "";
            this.EditPhoneTextbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.EditPhoneTextbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.EditPhoneTextbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.EditPhoneTextbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.EditPhoneTextbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.EditPhoneTextbox.FocusedState.FillColor = System.Drawing.Color.White;
            this.EditPhoneTextbox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditPhoneTextbox.ForeColor = System.Drawing.Color.DimGray;
            this.EditPhoneTextbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.EditPhoneTextbox.HoverState.FillColor = System.Drawing.Color.White;
            this.EditPhoneTextbox.IconLeft = ((System.Drawing.Image)(resources.GetObject("EditPhoneTextbox.IconLeft")));
            this.EditPhoneTextbox.IconLeftOffset = new System.Drawing.Point(7, 0);
            this.EditPhoneTextbox.Location = new System.Drawing.Point(38, 203);
            this.EditPhoneTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EditPhoneTextbox.MaxLength = 16;
            this.EditPhoneTextbox.Name = "EditPhoneTextbox";
            this.EditPhoneTextbox.PasswordChar = '\0';
            this.EditPhoneTextbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.EditPhoneTextbox.PlaceholderText = "Phone";
            this.EditPhoneTextbox.SelectedText = "";
            this.EditPhoneTextbox.Size = new System.Drawing.Size(192, 33);
            this.EditPhoneTextbox.TabIndex = 17;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(49, 273);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(21, 24);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 24;
            this.guna2PictureBox1.TabStop = false;
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.ImageRotate = 0F;
            this.guna2PictureBox2.Location = new System.Drawing.Point(46, 273);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.Size = new System.Drawing.Size(18, 20);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox2.TabIndex = 25;
            this.guna2PictureBox2.TabStop = false;
            // 
            // BirthdayLabel
            // 
            this.BirthdayLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BirthdayLabel.AutoSize = true;
            this.BirthdayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BirthdayLabel.ForeColor = System.Drawing.Color.Silver;
            this.BirthdayLabel.Location = new System.Drawing.Point(145, 296);
            this.BirthdayLabel.Name = "BirthdayLabel";
            this.BirthdayLabel.Size = new System.Drawing.Size(51, 15);
            this.BirthdayLabel.TabIndex = 23;
            this.BirthdayLabel.Text = "Birthday";
            this.BirthdayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EditBirthdayDateTimePicker
            // 
            this.EditBirthdayDateTimePicker.Animated = true;
            this.EditBirthdayDateTimePicker.AutoRoundedCorners = true;
            this.EditBirthdayDateTimePicker.BackColor = System.Drawing.Color.Transparent;
            this.EditBirthdayDateTimePicker.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.EditBirthdayDateTimePicker.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(218)))), ((int)(((byte)(223)))));
            this.EditBirthdayDateTimePicker.BorderRadius = 15;
            this.EditBirthdayDateTimePicker.BorderThickness = 1;
            this.EditBirthdayDateTimePicker.Checked = true;
            this.EditBirthdayDateTimePicker.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(218)))), ((int)(((byte)(223)))));
            this.EditBirthdayDateTimePicker.CheckedState.FillColor = System.Drawing.Color.White;
            this.EditBirthdayDateTimePicker.CheckedState.ForeColor = System.Drawing.Color.Gray;
            this.EditBirthdayDateTimePicker.CustomFormat = "yyyy/MM/dd";
            this.EditBirthdayDateTimePicker.FillColor = System.Drawing.Color.White;
            this.EditBirthdayDateTimePicker.FocusedColor = System.Drawing.Color.White;
            this.EditBirthdayDateTimePicker.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.EditBirthdayDateTimePicker.ForeColor = System.Drawing.Color.DarkGray;
            this.EditBirthdayDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.EditBirthdayDateTimePicker.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.EditBirthdayDateTimePicker.HoverState.FillColor = System.Drawing.Color.White;
            this.EditBirthdayDateTimePicker.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.EditBirthdayDateTimePicker.Location = new System.Drawing.Point(38, 269);
            this.EditBirthdayDateTimePicker.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.EditBirthdayDateTimePicker.MinDate = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            this.EditBirthdayDateTimePicker.Name = "EditBirthdayDateTimePicker";
            this.EditBirthdayDateTimePicker.Size = new System.Drawing.Size(192, 33);
            this.EditBirthdayDateTimePicker.TabIndex = 22;
            this.EditBirthdayDateTimePicker.TextOffset = new System.Drawing.Point(5, 0);
            this.EditBirthdayDateTimePicker.UseTransparentBackground = true;
            this.EditBirthdayDateTimePicker.Value = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.DeleteButton.BorderRadius = 9;
            this.DeleteButton.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.DeleteButton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.DeleteButton.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.DeleteButton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.DeleteButton.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.DeleteButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DeleteButton.ForeColor = System.Drawing.Color.White;
            this.DeleteButton.Location = new System.Drawing.Point(414, 328);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(144, 52);
            this.DeleteButton.TabIndex = 26;
            this.DeleteButton.Text = "Save Changes";
            this.DeleteButton.Click += new System.EventHandler(this.btnDelete);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 425);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.toolStrip1.Size = new System.Drawing.Size(600, 25);
            this.toolStrip1.TabIndex = 27;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripButton1.Text = "File";
            this.toolStripButton1.Click += new System.EventHandler(this.FileToolStrip);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(36, 22);
            this.toolStripButton2.Text = "Help";
            this.toolStripButton2.Click += new System.EventHandler(this.HelpToolStrip);
            // 
            // UC_EditStudent1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.guna2PictureBox2);
            this.Controls.Add(this.BirthdayLabel);
            this.Controls.Add(this.EditBirthdayDateTimePicker);
            this.Controls.Add(this.EditGPATextbox);
            this.Controls.Add(this.EditPhoneTextbox);
            this.Controls.Add(this.EditMajorTextbox);
            this.Controls.Add(this.EditNameTextbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "UC_EditStudent1";
            this.Size = new System.Drawing.Size(600, 450);
            this.Load += new System.EventHandler(this.UC_EditStudent1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox EditNameTextbox;
        private Guna.UI2.WinForms.Guna2TextBox EditMajorTextbox;
        private Guna.UI2.WinForms.Guna2TextBox EditGPATextbox;
        private Guna.UI2.WinForms.Guna2TextBox EditPhoneTextbox;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private System.Windows.Forms.Label BirthdayLabel;
        private Guna.UI2.WinForms.Guna2DateTimePicker EditBirthdayDateTimePicker;
        private Guna.UI2.WinForms.Guna2Button DeleteButton;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private Guna.UI2.WinForms.Guna2ControlBox MinimizeControlBox;
        private Guna.UI2.WinForms.Guna2ControlBox ExitControlBox;
    }
}
