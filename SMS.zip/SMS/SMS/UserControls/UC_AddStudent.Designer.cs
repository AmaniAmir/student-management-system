﻿namespace SMS_CSC235.UserControls
{
    partial class UC_AddStudent
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_AddStudent));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.DeleteButton = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.BirthdayDateTimePicker = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.BirthdayLabel = new System.Windows.Forms.Label();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.AddMajorTextbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.AddGPATextbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.AddNameTextbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.AddPhoneTextbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.AddIDTextbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.MinimizeControlBox = new Guna.UI2.WinForms.Guna2ControlBox();
            this.ExitControlBox = new Guna.UI2.WinForms.Guna2ControlBox();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 425);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.toolStrip1.Size = new System.Drawing.Size(600, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // DeleteButton
            // 
            this.DeleteButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.DeleteButton.BorderRadius = 9;
            this.DeleteButton.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.DeleteButton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.DeleteButton.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.DeleteButton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.DeleteButton.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.DeleteButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DeleteButton.ForeColor = System.Drawing.Color.White;
            this.DeleteButton.Location = new System.Drawing.Point(252, 361);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(106, 35);
            this.DeleteButton.TabIndex = 11;
            this.DeleteButton.Text = "Add";
            this.DeleteButton.Click += new System.EventHandler(this.btnAdd);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.label1.Location = new System.Drawing.Point(183, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 37);
            this.label1.TabIndex = 9;
            this.label1.Text = "Adding Student";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // BirthdayDateTimePicker
            // 
            this.BirthdayDateTimePicker.Animated = true;
            this.BirthdayDateTimePicker.AutoRoundedCorners = true;
            this.BirthdayDateTimePicker.BackColor = System.Drawing.Color.Transparent;
            this.BirthdayDateTimePicker.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BirthdayDateTimePicker.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(218)))), ((int)(((byte)(223)))));
            this.BirthdayDateTimePicker.BorderRadius = 15;
            this.BirthdayDateTimePicker.BorderThickness = 1;
            this.BirthdayDateTimePicker.Checked = true;
            this.BirthdayDateTimePicker.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(218)))), ((int)(((byte)(223)))));
            this.BirthdayDateTimePicker.CheckedState.FillColor = System.Drawing.Color.White;
            this.BirthdayDateTimePicker.CheckedState.ForeColor = System.Drawing.Color.Gray;
            this.BirthdayDateTimePicker.CustomFormat = "yyyy/MM/dd";
            this.BirthdayDateTimePicker.FillColor = System.Drawing.Color.White;
            this.BirthdayDateTimePicker.FocusedColor = System.Drawing.Color.White;
            this.BirthdayDateTimePicker.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BirthdayDateTimePicker.ForeColor = System.Drawing.Color.DarkGray;
            this.BirthdayDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.BirthdayDateTimePicker.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.BirthdayDateTimePicker.HoverState.FillColor = System.Drawing.Color.White;
            this.BirthdayDateTimePicker.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.BirthdayDateTimePicker.Location = new System.Drawing.Point(357, 276);
            this.BirthdayDateTimePicker.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.BirthdayDateTimePicker.MinDate = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            this.BirthdayDateTimePicker.Name = "BirthdayDateTimePicker";
            this.BirthdayDateTimePicker.Size = new System.Drawing.Size(192, 33);
            this.BirthdayDateTimePicker.TabIndex = 18;
            this.BirthdayDateTimePicker.TextOffset = new System.Drawing.Point(5, 0);
            this.BirthdayDateTimePicker.UseTransparentBackground = true;
            this.BirthdayDateTimePicker.Value = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            this.BirthdayDateTimePicker.ValueChanged += new System.EventHandler(this.BirthdayDateTimePicker_ValueChanged);
            // 
            // BirthdayLabel
            // 
            this.BirthdayLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BirthdayLabel.AutoSize = true;
            this.BirthdayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BirthdayLabel.ForeColor = System.Drawing.Color.Silver;
            this.BirthdayLabel.Location = new System.Drawing.Point(472, 303);
            this.BirthdayLabel.Name = "BirthdayLabel";
            this.BirthdayLabel.Size = new System.Drawing.Size(51, 15);
            this.BirthdayLabel.TabIndex = 19;
            this.BirthdayLabel.Text = "Birthday";
            this.BirthdayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BirthdayLabel.Click += new System.EventHandler(this.BirthdayLabell);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(368, 280);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(21, 24);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 20;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.Click += new System.EventHandler(this.guna2PictureBox1_Click);
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.ImageRotate = 0F;
            this.guna2PictureBox2.Location = new System.Drawing.Point(367, 280);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.Size = new System.Drawing.Size(16, 20);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox2.TabIndex = 21;
            this.guna2PictureBox2.TabStop = false;
            this.guna2PictureBox2.Click += new System.EventHandler(this.guna2PictureBox2_Click);
            // 
            // AddMajorTextbox
            // 
            this.AddMajorTextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddMajorTextbox.Animated = true;
            this.AddMajorTextbox.AutoRoundedCorners = true;
            this.AddMajorTextbox.BorderRadius = 15;
            this.AddMajorTextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AddMajorTextbox.DefaultText = "";
            this.AddMajorTextbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.AddMajorTextbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.AddMajorTextbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AddMajorTextbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AddMajorTextbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.AddMajorTextbox.FocusedState.FillColor = System.Drawing.Color.White;
            this.AddMajorTextbox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddMajorTextbox.ForeColor = System.Drawing.Color.DimGray;
            this.AddMajorTextbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.AddMajorTextbox.HoverState.FillColor = System.Drawing.Color.White;
            this.AddMajorTextbox.IconLeft = ((System.Drawing.Image)(resources.GetObject("AddMajorTextbox.IconLeft")));
            this.AddMajorTextbox.IconLeftOffset = new System.Drawing.Point(7, 0);
            this.AddMajorTextbox.Location = new System.Drawing.Point(50, 210);
            this.AddMajorTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AddMajorTextbox.MaxLength = 16;
            this.AddMajorTextbox.Name = "AddMajorTextbox";
            this.AddMajorTextbox.PasswordChar = '\0';
            this.AddMajorTextbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.AddMajorTextbox.PlaceholderText = "Major";
            this.AddMajorTextbox.SelectedText = "";
            this.AddMajorTextbox.Size = new System.Drawing.Size(192, 33);
            this.AddMajorTextbox.TabIndex = 15;
            this.AddMajorTextbox.TextChanged += new System.EventHandler(this.guna2TextBox4_TextChanged);
            // 
            // AddGPATextbox
            // 
            this.AddGPATextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddGPATextbox.Animated = true;
            this.AddGPATextbox.AutoRoundedCorners = true;
            this.AddGPATextbox.BorderRadius = 15;
            this.AddGPATextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AddGPATextbox.DefaultText = "";
            this.AddGPATextbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.AddGPATextbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.AddGPATextbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AddGPATextbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AddGPATextbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.AddGPATextbox.FocusedState.FillColor = System.Drawing.Color.White;
            this.AddGPATextbox.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.AddGPATextbox.ForeColor = System.Drawing.Color.DimGray;
            this.AddGPATextbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.AddGPATextbox.HoverState.FillColor = System.Drawing.Color.White;
            this.AddGPATextbox.IconLeft = ((System.Drawing.Image)(resources.GetObject("AddGPATextbox.IconLeft")));
            this.AddGPATextbox.IconLeftOffset = new System.Drawing.Point(7, 0);
            this.AddGPATextbox.Location = new System.Drawing.Point(357, 210);
            this.AddGPATextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AddGPATextbox.MaxLength = 16;
            this.AddGPATextbox.Name = "AddGPATextbox";
            this.AddGPATextbox.PasswordChar = '\0';
            this.AddGPATextbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.AddGPATextbox.PlaceholderText = "GPA";
            this.AddGPATextbox.SelectedText = "";
            this.AddGPATextbox.Size = new System.Drawing.Size(192, 33);
            this.AddGPATextbox.TabIndex = 14;
            this.AddGPATextbox.TextChanged += new System.EventHandler(this.guna2TextBox3_TextChanged);
            // 
            // AddNameTextbox
            // 
            this.AddNameTextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddNameTextbox.Animated = true;
            this.AddNameTextbox.AutoRoundedCorners = true;
            this.AddNameTextbox.BorderRadius = 15;
            this.AddNameTextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AddNameTextbox.DefaultText = "";
            this.AddNameTextbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.AddNameTextbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.AddNameTextbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AddNameTextbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AddNameTextbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.AddNameTextbox.FocusedState.FillColor = System.Drawing.Color.White;
            this.AddNameTextbox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNameTextbox.ForeColor = System.Drawing.Color.DimGray;
            this.AddNameTextbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.AddNameTextbox.HoverState.FillColor = System.Drawing.Color.White;
            this.AddNameTextbox.IconLeft = ((System.Drawing.Image)(resources.GetObject("AddNameTextbox.IconLeft")));
            this.AddNameTextbox.IconLeftOffset = new System.Drawing.Point(7, 0);
            this.AddNameTextbox.Location = new System.Drawing.Point(357, 144);
            this.AddNameTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AddNameTextbox.MaxLength = 16;
            this.AddNameTextbox.Name = "AddNameTextbox";
            this.AddNameTextbox.PasswordChar = '\0';
            this.AddNameTextbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.AddNameTextbox.PlaceholderText = "Name";
            this.AddNameTextbox.SelectedText = "";
            this.AddNameTextbox.Size = new System.Drawing.Size(192, 33);
            this.AddNameTextbox.TabIndex = 13;
            this.AddNameTextbox.TextChanged += new System.EventHandler(this.guna2TextBox2_TextChanged);
            // 
            // AddPhoneTextbox
            // 
            this.AddPhoneTextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddPhoneTextbox.Animated = true;
            this.AddPhoneTextbox.AutoRoundedCorners = true;
            this.AddPhoneTextbox.BorderRadius = 15;
            this.AddPhoneTextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AddPhoneTextbox.DefaultText = "";
            this.AddPhoneTextbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.AddPhoneTextbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.AddPhoneTextbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AddPhoneTextbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AddPhoneTextbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.AddPhoneTextbox.FocusedState.FillColor = System.Drawing.Color.White;
            this.AddPhoneTextbox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddPhoneTextbox.ForeColor = System.Drawing.Color.DimGray;
            this.AddPhoneTextbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.AddPhoneTextbox.HoverState.FillColor = System.Drawing.Color.White;
            this.AddPhoneTextbox.IconLeft = ((System.Drawing.Image)(resources.GetObject("AddPhoneTextbox.IconLeft")));
            this.AddPhoneTextbox.IconLeftOffset = new System.Drawing.Point(7, 0);
            this.AddPhoneTextbox.Location = new System.Drawing.Point(50, 276);
            this.AddPhoneTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AddPhoneTextbox.MaxLength = 16;
            this.AddPhoneTextbox.Name = "AddPhoneTextbox";
            this.AddPhoneTextbox.PasswordChar = '\0';
            this.AddPhoneTextbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.AddPhoneTextbox.PlaceholderText = "Phone";
            this.AddPhoneTextbox.SelectedText = "";
            this.AddPhoneTextbox.Size = new System.Drawing.Size(192, 33);
            this.AddPhoneTextbox.TabIndex = 12;
            this.AddPhoneTextbox.TextChanged += new System.EventHandler(this.guna2TextBox1_TextChanged);
            // 
            // AddIDTextbox
            // 
            this.AddIDTextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddIDTextbox.Animated = true;
            this.AddIDTextbox.AutoRoundedCorners = true;
            this.AddIDTextbox.BorderRadius = 15;
            this.AddIDTextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AddIDTextbox.DefaultText = "";
            this.AddIDTextbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.AddIDTextbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.AddIDTextbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AddIDTextbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AddIDTextbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.AddIDTextbox.FocusedState.FillColor = System.Drawing.Color.White;
            this.AddIDTextbox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddIDTextbox.ForeColor = System.Drawing.Color.DimGray;
            this.AddIDTextbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.AddIDTextbox.HoverState.FillColor = System.Drawing.Color.White;
            this.AddIDTextbox.IconLeft = ((System.Drawing.Image)(resources.GetObject("AddIDTextbox.IconLeft")));
            this.AddIDTextbox.IconLeftOffset = new System.Drawing.Point(7, 0);
            this.AddIDTextbox.Location = new System.Drawing.Point(50, 144);
            this.AddIDTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AddIDTextbox.MaxLength = 16;
            this.AddIDTextbox.Name = "AddIDTextbox";
            this.AddIDTextbox.PasswordChar = '\0';
            this.AddIDTextbox.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.AddIDTextbox.PlaceholderText = "ID";
            this.AddIDTextbox.SelectedText = "";
            this.AddIDTextbox.Size = new System.Drawing.Size(192, 33);
            this.AddIDTextbox.TabIndex = 10;
            this.AddIDTextbox.TextChanged += new System.EventHandler(this.DeleteStudentTextBox_TextChanged);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripButton1.Text = "File";
            this.toolStripButton1.Click += new System.EventHandler(this.FileToolStrip);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(36, 22);
            this.toolStripButton2.Text = "Help";
            this.toolStripButton2.Click += new System.EventHandler(this.HelpToolStrip);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.MinimizeControlBox);
            this.panel1.Controls.Add(this.ExitControlBox);
            this.panel1.Location = new System.Drawing.Point(544, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(53, 29);
            this.panel1.TabIndex = 22;
            // 
            // MinimizeControlBox
            // 
            this.MinimizeControlBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MinimizeControlBox.Animated = true;
            this.MinimizeControlBox.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.MinimizeControlBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MinimizeControlBox.FillColor = System.Drawing.Color.Transparent;
            this.MinimizeControlBox.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.MinimizeControlBox.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.MinimizeControlBox.HoverState.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.MinimizeControlBox.IconColor = System.Drawing.Color.Gray;
            this.MinimizeControlBox.Location = new System.Drawing.Point(10, 5);
            this.MinimizeControlBox.Name = "MinimizeControlBox";
            this.MinimizeControlBox.Size = new System.Drawing.Size(14, 19);
            this.MinimizeControlBox.TabIndex = 13;
            // 
            // ExitControlBox
            // 
            this.ExitControlBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ExitControlBox.Animated = true;
            this.ExitControlBox.BorderRadius = 2;
            this.ExitControlBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitControlBox.FillColor = System.Drawing.Color.Transparent;
            this.ExitControlBox.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.ExitControlBox.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.ExitControlBox.HoverState.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(16)))), ((int)(((byte)(61)))));
            this.ExitControlBox.IconColor = System.Drawing.Color.Gray;
            this.ExitControlBox.Location = new System.Drawing.Point(30, 5);
            this.ExitControlBox.Name = "ExitControlBox";
            this.ExitControlBox.Size = new System.Drawing.Size(12, 19);
            this.ExitControlBox.TabIndex = 12;
            // 
            // UC_AddStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.guna2PictureBox2);
            this.Controls.Add(this.BirthdayLabel);
            this.Controls.Add(this.BirthdayDateTimePicker);
            this.Controls.Add(this.AddMajorTextbox);
            this.Controls.Add(this.AddGPATextbox);
            this.Controls.Add(this.AddNameTextbox);
            this.Controls.Add(this.AddPhoneTextbox);
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.AddIDTextbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "UC_AddStudent";
            this.Size = new System.Drawing.Size(600, 450);
            this.Load += new System.EventHandler(this.UC_AddStudent_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private Guna.UI2.WinForms.Guna2Button DeleteButton;
        private Guna.UI2.WinForms.Guna2TextBox AddIDTextbox;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox AddPhoneTextbox;
        private Guna.UI2.WinForms.Guna2TextBox AddNameTextbox;
        private Guna.UI2.WinForms.Guna2TextBox AddGPATextbox;
        private Guna.UI2.WinForms.Guna2TextBox AddMajorTextbox;
        private Guna.UI2.WinForms.Guna2DateTimePicker BirthdayDateTimePicker;
        private System.Windows.Forms.Label BirthdayLabel;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2ControlBox MinimizeControlBox;
        private Guna.UI2.WinForms.Guna2ControlBox ExitControlBox;
    }
}
