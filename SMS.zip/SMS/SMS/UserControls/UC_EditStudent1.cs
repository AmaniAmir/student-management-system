﻿using SMS_CSC235.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace SMS_CSC235.UserControls
{
    public partial class UC_EditStudent1 : UserControl
    {
        private Dashboard dashboard;
        private cStudent selectedStudent;

        public UC_EditStudent1(Dashboard form, cStudent student)
        {
            InitializeComponent();
            dashboard = form;
            selectedStudent = student;

            EditNameTextbox.Text = student.Name;
            EditMajorTextbox.Text = student.Major;
            EditGPATextbox.Text = student.GPA.ToString();
            EditBirthdayDateTimePicker.Value = student.Birthday;
            EditPhoneTextbox.Text = student.Phone;
        }

        private void btnDelete(object sender, EventArgs e)
        {
            if (dashboard.LoggedInRole == "Teacher")
            {
                MessageBox.Show("This feature is only available for Admins.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!float.TryParse(EditGPATextbox.Text.Trim(), out float updatedGPA))
            {
                MessageBox.Show("Please enter a valid numeric GPA!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (updatedGPA < 0 || updatedGPA > 4)
            {
                MessageBox.Show("GPA must be between 0 and 4!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            selectedStudent.Name = EditNameTextbox.Text.Trim();
            selectedStudent.Major = EditMajorTextbox.Text.Trim();
            selectedStudent.GPA = updatedGPA;
            selectedStudent.Birthday = EditBirthdayDateTimePicker.Value;
            selectedStudent.Phone = EditPhoneTextbox.Text.Trim();

            dashboard.SaveStudentsToFile();

            MessageBox.Show("Student details updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void HelpToolStrip(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.Google.com");
        }

        private void FileToolStrip(object sender, EventArgs e)
        {
            MessageBox.Show("Coming Soon!");
        }


        //--------------------------------------------------------------


        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void AddNameTextbox_TextChanged(object sender, EventArgs e)
        {
        }

        private void EditGPATextbox_TextChanged(object sender, EventArgs e)
        {
        }

        private void UC_EditStudent1_Load(object sender, EventArgs e)
        {
        }
    }
}
